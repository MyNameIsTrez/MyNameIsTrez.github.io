class Food {
  constructor() {
    this.pos = this.newPos();
  }

  draw() {
    push();
    noStroke();
    fill(255, 0, 0);
    square(this.pos.x * scl, this.pos.y * scl, scl);
    pop();
  }

  newPos() {
    // Guarantees food isn't placed where the snake is.
    const pxlsWithoutSnake = [];

    for (let x = 0; x < w; x++) {
      for (let y = 0; y < h; y++) {
        if (pxls[x][y] === 0) {
          pxlsWithoutSnake.push({'x': x, 'y': y});
        }
      }
    }
    
    const pos = random(pxlsWithoutSnake);
    // console.log(pos.x, pos.y, pxlsWithoutSnake);
    return createVector(pos.x, pos.y);
  }

  setNewPos() {
    this.pos = this.newPos();
  }
}