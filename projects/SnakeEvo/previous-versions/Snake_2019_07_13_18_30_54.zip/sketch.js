let snake;
let food;
const scl = 100;
const width = 500,
  height = 500;
let w, h;
let score = 0;
let pxls;
const debugColors = false;

function setup() {
  createCanvas(width, height);
  w = floor(width / scl);
  h = floor(height / scl);

  emptyPxls();
  snake = new Snake();
  addSnakePxls();
  food = new Food();
  addFoodPxls();

  background(0);
  food.draw();
  snake.draw();
  drawScore();
}

function step() {
  emptyPxls();
  addSnakePxls();
  addFoodPxls();

  snake.update();

  if (snake.checkDeath()) {
    console.log("GAME OVER");
    background(255, 0, 0); // Why doesn't this work?
    noLoop();
    textSize(50);
    text('GAME\nOVER', width/2 - 60, height/3);
    
    text(`Score: ${score}`, width/2 - 80, height * 2/3);
    return;
  }

  if (snake.eat(food.pos)) {
    snake.grow();
    score++;
    food.setNewPos();
  }

  background(0);
  food.draw();
  snake.draw();
  drawScore();
}

// function draw() {
//   if (frameCount % 12 === 0) { // Slows the game down.
//     emptyPxls();
//     addSnakePxls();
//     addFoodPxls();

//     snake.update();

//     if (snake.checkDeath()) {
//       console.log("GAME OVER");
//       // background(255, 0, 0); // Why doesn't this work?
//       noLoop();
//     }

//     if (snake.eat(food.pos)) {
//       snake.grow();
//       score++;
//       food.setNewPos();
//     }

//     background(0);
//     food.draw();
//     snake.draw();
//     drawScore();
//   }
// }

function emptyPxls() {
  pxls = [];
  for (let x = 0; x < w; x++) {
    pxls.push([]);
    for (let y = 0; y < h; y++) {
      pxls[x][y] = 0;
    }
  }
}

function addSnakePxls() {
  for (let i = 0; i < snake.body.length; i++) {
    const x = snake.body[i].x;
    const y = snake.body[i].y;
    pxls[x][y] = 1;
  }
}

function addFoodPxls() {
  const x = food.pos.x;
  const y = food.pos.y;
  pxls[x][y] = 2;
}

function drawScore() {
  push();
  textSize(30);
  stroke(0);
  strokeWeight(3);
  fill(150, 255, 0);
  text(score, scl / 2 - 10, scl / 2 + 10);
  pop();
}

function keyPressed() {
  const short = snake.body.length === 1 || snake.body[0].x === snake.body[1].x && snake.body[0].y === snake.body[1].y;
  
  switch (keyCode) {
    case UP_ARROW:
      if (short || snake.yDir !== 1) { // The snake can't turn back.
        snake.setDir(0, -1);
        step();
      }
      break;
    case DOWN_ARROW:
      if (short || snake.yDir !== -1) {
        snake.setDir(0, 1);
        step();
      }
      break;
    case LEFT_ARROW:
      if (short || snake.xDir !== 1) {
        snake.setDir(-1, 0);
        step();
      }
      break;
    case RIGHT_ARROW:
      if (short || snake.xDir !== -1) {
        snake.setDir(1, 0);
        step();
      }
      break;
  }
  if (key === ' ') {
    snake.grow();
  }
}