class Snake {
  constructor() {
    this.body = [];
    this.body[0] = this.newPos();
    this.xDir = 0;
    this.yDir = 1;
  }

  update() {
    const head = this.body[this.body.length - 1].copy();
    this.body.shift();
    head.x += this.xDir;
    head.y += this.yDir;
    this.body.push(head);
  }

  draw() {
    push();
    noStroke();
    for (let i = 0; i < this.body.length; i++) {
      if (debugColors) {
      if (i === 0) {
        fill(255, 200, 0, 150);
      } else if (i === this.body.length - 1) {
        fill(0, 0, 255, 150);
      } else {
        fill(255, 150);
      }
      } else {
        fill(255);
      }
      square(this.body[i].x * scl, this.body[i].y * scl, scl);
    }
    pop();
  }

  setDir(x, y) {
    this.xDir = x;
    this.yDir = y;
  }

  eat(pos) {
    const x = this.body[this.body.length - 1].x;
    const y = this.body[this.body.length - 1].y;
    if (x === pos.x && y === pos.y) {
      return true;
    } else {
      return false;
    }
  }

  newPos() {
    const x = floor(w / 2);
    const y = floor(h / 2);
    const pos = createVector(x, y);
    return pos;
  }

  grow() {
    const head = this.body[this.body.length - 1].copy();
    this.body.push(head);
  }

  checkDeath() {
    const x = this.body[this.body.length - 1].x;
    const y = this.body[this.body.length - 1].y;
    // If offscreen.
    if (x < 0 || x >= w || y < 0 || y >= h) {
      return true;
    }
    // If the snake is eating itself.
    for (let i = 0; i < this.body.length - 1; i++) {
      const part = this.body[i];
      if (part.x === x && part.y === y) {
        return true;
      }
    }
    return false;
  }
}