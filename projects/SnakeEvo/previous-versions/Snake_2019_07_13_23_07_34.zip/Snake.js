class Snake {
  constructor(index, brain) {
    this.index = index;
    this.agentX = index % agentsHor;
    this.agentY = floor(index / agentsVer);

    this.body = [];
    this.body[0] = this.newGenPos();
    this.xDir = 0;
    this.yDir = 1;
    this.alive = true;

    // Neuroevolution.
    this.score = 0;
    this.fitness = 0;
    if (brain) {
      this.brain = brain.copy();
    } else {
      // The 'pixels' (same as w*h) coming from pxls.
      const inputs = w * h;
      // Left, forward, right.
      const outputs = 3;
      // ceil((#inputs + #outputs) / 2).
      const hiddenLayers = ceil((inputs + outputs) / 2);

      this.brain = new NeuralNetwork(inputs, hiddenLayers, outputs);
    }
  }

  update() {
    const head = this.body[this.body.length - 1].copy();
    this.body.shift();
    head.x += this.xDir;
    head.y += this.yDir;
    this.body.push(head);
  }

  draw() {
    push();
    noStroke();
    for (let i = 0; i < this.body.length; i++) {
      if (debugColors) {
        if (i === 0) {
          fill(255, 200, 0, 150);
        } else if (i === this.body.length - 1) {
          fill(0, 0, 255, 150);
        } else {
          fill(255, 150);
        }
      } else {
        fill(255);
      }
      const x = this.body[i].x * scl + this.agentX * agentWidth;
      const y = this.body[i].y * scl + this.agentY * agentHeight;
      square(x, y, scl);
    }
    pop();
  }

  setDir(x, y) {
    this.xDir = x;
    this.yDir = y;
  }

  eat(pos) {
    const x = this.body[this.body.length - 1].x;
    const y = this.body[this.body.length - 1].y;
    if (x === pos.x && y === pos.y) {
      return true;
    } else {
      return false;
    }
  }

  newGenPos() {
    const x = floor(w / 2);
    const y = floor(h / 2);
    const pos = createVector(x, y);
    return pos;
  }

  grow() {
    const head = this.body[this.body.length - 1].copy();
    this.body.push(head);
  }

  checkDeath() {
    const x = this.body[this.body.length - 1].x;
    const y = this.body[this.body.length - 1].y;
    // If the snake is offscreen.
    if (x < 0 || x >= w || y < 0 || y >= h) {
      return true;
    }
    // If the snake is eating itself.
    for (let i = 0; i < this.body.length - 1; i++) {
      const part = this.body[i];
      if (part.x === x && part.y === y) {
        return true;
      }
    }
    return false;
  }
}