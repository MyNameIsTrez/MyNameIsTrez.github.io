let snakes = [];
let foods = [];

const width = innerWidth - 5;
const height = innerHeight - 6;
const w = 9;
const h = 9;

const agentsHor = 3;
const agentsVer = 3;
const agentsCount = agentsHor * agentsVer;

const maxSclWidth = width / w / agentsHor;
const maxSclHeight = height / h / agentsVer;
const scl = maxSclWidth < maxSclHeight ? maxSclWidth : maxSclHeight;
const agentWidth = scl * w;
const agentHeight = scl * h;
const finalWidth = agentWidth * agentsHor;
const finalHeight = agentHeight * agentsVer;

let pxls = [];
const debugColors = false;
let generation = 1;

function setup() {
  createCanvas(finalWidth, finalHeight);
  background(0);

  for (let i = 0; i < agentsCount; i++) {
    emptyPxls(i);

    const snake = new Snake(i);
    snakes.push(snake);
    addSnakePxls(i, snake);

    const food = new Food(i);
    foods.push(food);
    addFoodPxls(i, food);
  }

  for (const food of foods) {
    food.draw();
  }
  for (const snake of snakes) {
    snake.draw();
  }
  for (let i = 0; i < agentsCount; i++) {
    drawAgentBorder(i);
  }

  drawGenCount();
}

function draw() {
  if (frameCount % 12 === 0) { // Slows the game down.
    // Check if all snakes are dead. If so, we go to the next generation.
    let allSnakesDead = true;
    for (const snake of snakes) {
      if (snake.alive) {
        allSnakesDead = false;
      }
    }
    if (allSnakesDead) {
      nextGeneration();
    }

    background(0);
    for (let i = 0; i < agentsCount; i++) {
      const snake = snakes[i];
      const food = foods[i];
      if (snake.alive === true) {
        emptyPxls(i);
        addSnakePxls(i, snake);
        addFoodPxls(i, food);

        snake.update();

        if (snake.checkDeath()) {
          snake.alive = false;
          savedSnakes.push(snake);
        }

        if (snake.eat(food.pos)) {
          snake.grow();
          snake.score++;
          food.setNewPos();
        }
      }
      food.draw();
      snake.draw();
      drawAgentBorder(i);
    }
    drawGenCount();
  }
}

function emptyPxls(i) {
  pxls[i] = [];
  for (let x = 0; x < w; x++) {
    pxls[i].push([]);
    for (let y = 0; y < h; y++) {
      pxls[i][x][y] = 0;
    }
  }
}

function addSnakePxls(i, snake) {
  for (let j = 0; j < snake.body.length; j++) {
    const x = snake.body[j].x;
    const y = snake.body[j].y;
    pxls[i][x][y] = 1;
  }
}

function addFoodPxls(i, food) {
  const x = food.pos.x;
  const y = food.pos.y;
  pxls[i][x][y] = 2;
}

function drawAgentBorder(i) {
  const agentX = i % agentsHor;
  const agentY = floor(i / agentsVer);

  push();
  noFill();
  strokeWeight(3);
  stroke(180);
  rect(agentX * agentWidth, agentY * agentHeight, agentWidth, agentHeight);
  pop();
}

function drawGenCount() {
  push();
  textSize(30);
  stroke(0);
  strokeWeight(3);
  fill(150, 255, 0);
  text(`Generation: ${generation}`, 10, 35);
  pop();
}

// function keyPressed() {
//   const short = snake.body.length === 1 || snake.body[0].x === snake.body[1].x && snake.body[0].y === snake.body[1].y;

//   switch (keyCode) {
//     case UP_ARROW:
//       if (short || snake.yDir !== 1) { // The snake can't turn back.
//         snake.setDir(0, -1);
//       }
//       break;
//     case DOWN_ARROW:
//       if (short || snake.yDir !== -1) {
//         snake.setDir(0, 1);
//       }
//       break;
//     case LEFT_ARROW:
//       if (short || snake.xDir !== 1) {
//         snake.setDir(-1, 0);
//       }
//       break;
//     case RIGHT_ARROW:
//       if (short || snake.xDir !== -1) {
//         snake.setDir(1, 0);
//       }
//       break;
//   }
//   if (key === ' ') {
//     snake.grow();
//   }
// }