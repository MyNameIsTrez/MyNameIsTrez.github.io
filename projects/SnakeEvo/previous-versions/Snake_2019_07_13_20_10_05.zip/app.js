let snakes = [];
let food;

const width = innerWidth - 5;
const height = innerHeight - 6;
const w = 5;
const h = 5;
const agentsHor = 2;
const agentsVer = 2;

const maxSclWidth = width / w / agentsHor;
const maxSclHeight = height / h / agentsVer;
const scl = maxSclWidth < maxSclHeight ? maxSclWidth : maxSclHeight;
const agentWidth = scl * w;
const agentHeight = scl * h;
const finalWidth = agentWidth * agentsHor;
const finalHeight = agentHeight * agentsVer;

let pxls;
const debugColors = false;
let generation = 1;

function setup() {
  createCanvas(finalWidth, finalHeight);

  emptyPxls();
  snakes.push(new Snake());
  addSnakePxls();
  food = new Food();
  addFoodPxls();

  background(0);
  food.draw();
  snake.draw();
  drawAgentBorder();
  drawScore();
}

function draw() {
  for (const snake of snakes) {
    if (frameCount % 12 === 0) { // Slows the game down.
      emptyPxls();
      addSnakePxls();
      addFoodPxls();

      snake.update();

      if (snake.checkDeath()) {
        // generation++;
        console.log('game over');
        return;
      }

      if (snake.eat(food.pos)) {
        snake.grow();
        snake.score++;
        food.setNewPos();
      }

      background(0);
      food.draw();
      snake.draw();
      drawAgentBorder();
      drawScore();
    }
  }
}

function emptyPxls() {
  pxls = [];
  for (let x = 0; x < w; x++) {
    pxls.push([]);
    for (let y = 0; y < h; y++) {
      pxls[x][y] = 0;
    }
  }
}

function addSnakePxls() {
  for (let i = 0; i < snake.body.length; i++) {
    const x = snake.body[i].x;
    const y = snake.body[i].y;
    pxls[x][y] = 1;
  }
}

function addFoodPxls() {
  const x = food.pos.x;
  const y = food.pos.y;
  pxls[x][y] = 2;
}

function drawAgentBorder() {
  push();
  noFill();
  stroke(100);
  rect(0, 0, agentWidth, agentHeight);
  pop();
}

function drawScore() {
  push();
  textSize(30);
  stroke(0);
  strokeWeight(3);
  fill(150, 255, 0);
  text(`Score: ${snake.score}`, scl / 2 - 20, scl / 2 + 10);
  text(`Generation: ${generation}`, scl / 2 - 20, scl / 2 + 50);
  pop();
}

function keyPressed() {
  const short = snake.body.length === 1 || snake.body[0].x === snake.body[1].x && snake.body[0].y === snake.body[1].y;

  switch (keyCode) {
    case UP_ARROW:
      if (short || snake.yDir !== 1) { // The snake can't turn back.
        snake.setDir(0, -1);
      }
      break;
    case DOWN_ARROW:
      if (short || snake.yDir !== -1) {
        snake.setDir(0, 1);
      }
      break;
    case LEFT_ARROW:
      if (short || snake.xDir !== 1) {
        snake.setDir(-1, 0);
      }
      break;
    case RIGHT_ARROW:
      if (short || snake.xDir !== -1) {
        snake.setDir(1, 0);
      }
      break;
  }
  if (key === ' ') {
    snake.grow();
  }
}